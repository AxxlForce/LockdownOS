#!/usr/bin/env python

from distutils.core import setup

setup(name='mcpi',
      version='0.1.1',
      description='API for Minecraft Pi',
      author='Mojang',
      url='http://pi.minecraft.net/',
      packages=['mcpi'],
     )
